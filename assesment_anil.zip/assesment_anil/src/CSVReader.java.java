import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;



public class CSVReader {
//declaring all the fields in Trade class

    static class Trade {
        int id;
        String name;
        String timestamp;
        String type;
        int quantity;
        int rate;

        public int getRate() {
            return rate;
        }

        public int getId() {
            return id;
        }

//fetching data from input file

        public Trade(String[] tradeDetails) {
            this.id = Integer.parseInt(tradeDetails[0]);
            this.name = tradeDetails[1];
            this.timestamp = tradeDetails[2];
            this.type = tradeDetails[3];
            this.quantity = Integer.parseInt(tradeDetails[4]);
            this.rate = Integer.parseInt(tradeDetails[5]);
        }
    }

//main method and reading input file
    public static void main(String[] args) {
        String line = "";
        String splitBy = ",";
        List<Trade> orderBook = new ArrayList<Trade>();
        List<String> ordersClosed = new ArrayList<>();
        try {
            BufferedReader br = new BufferedReader(new FileReader("./EXAMPLE_ORDERS.CSV"));
            while ((line = br.readLine()) != null)
            {
                String[] tradeDetails = line.split(splitBy);
                Trade trade = new Trade(tradeDetails);
                matchingEngine(orderBook, trade, ordersClosed);
            }
            File csvOutputFile = new File("./OUTPUT.csv");
            try (PrintWriter pw = new PrintWriter(csvOutputFile)) {
                ordersClosed.stream()
                        .forEach(pw::println);
            }
        }
        catch(IOException e) {
            e.printStackTrace();
        }
    }

//logic for Matcingengine 
    static void matchingEngine(List<Trade> orderBook, Trade trade, List<String> ordersClosed) {
        Map<Integer, List<Trade>> tradeStream = orderBook.stream()
                .filter(bookTrade -> !bookTrade.type.equals(trade.type) && bookTrade.quantity == trade.quantity)
                .collect(Collectors.groupingBy(Trade::getRate));
        Trade matchedTrade = null;
        if(!tradeStream.keySet().isEmpty()) {
        if(trade.type == "BUY") {
            matchedTrade = tradeStream.get(tradeStream.keySet().stream().min(Integer::compareTo).get()).stream().min(Comparator.comparing( Trade :: getId)).orElse(null);
        } else {
            matchedTrade = tradeStream.get(tradeStream.keySet().stream().max(Integer::compareTo).get()).stream().min(Comparator.comparing( Trade :: getId)).orElse(null);
        }
        }
        if(matchedTrade != null) {
            orderBook.remove(matchedTrade);
            ordersClosed.add(trade.id+ "," + matchedTrade.id +","+ trade.timestamp+","+ trade.quantity+","+ matchedTrade.rate);
        } else {
            orderBook.add(trade);
        }
    }
}